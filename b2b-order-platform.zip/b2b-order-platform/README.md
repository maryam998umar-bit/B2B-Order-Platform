# B2B Order Management Platform

Multi-role ordering system for a simulated distributor: products, carts, orders, invoices, stock status, admin controls.

## Run
```bash
cp .env.example .env     # set JWT_SECRET and admin credentials
docker compose up --build
# open http://localhost:3000
```
Migrations (`migrations/*.sql`) run automatically at startup and are tracked in `schema_migrations`. Demo products and the admin user are seeded on first run.

## Roles
- **customer** (self-register): browse products, manage cart, place orders, view own orders/invoices.
- **admin**: manage products and stock, view all orders, move orders through `placed -> shipped -> delivered` (or `cancelled`, which restocks), read the audit log.

## API
| Method | Path | Role |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | public |
| GET | /api/products | any |
| POST / PATCH | /api/products, /api/products/:id | admin |
| GET | /api/cart | customer |
| PUT | /api/cart/items `{product_id, quantity}` (0 removes) | customer |
| POST | /api/orders (checkout cart) | customer |
| GET | /api/orders, /api/orders/:id/invoice | any (scoped) |
| PATCH | /api/orders/:id/status | admin |
| GET | /api/audit | admin |

## Design decisions
- Checkout runs in one transaction with `SELECT ... FOR UPDATE` on product rows, so concurrent orders cannot oversell.
- Prices stored as integer cents; order items snapshot the unit price.
- Every state change writes to `audit_logs` (actor, action, entity, detail).
- Stack deviation (documented per handbook): Express + vanilla JS frontend instead of NestJS + React/Next.js, to keep the project small and reviewable.

## Known limitations / next steps
- No refresh tokens, rate limiting or password reset. Add helmet and rate limiting before production.
- Tests are minimal; add API integration tests (supertest + a test DB) as evidence for the validation step.
- Frontend is functional, not polished; port to React/Next.js as the extension task.
- No pagination on orders/products.

## Handbook mapping
Role-based access: `auth(roles)` middleware. REST API: `src/server.js`. Migrations: `migrations/`. Validation/errors: per-route checks + central error handler. Audit: `audit_logs`. Deployment: `Dockerfile`, `docker-compose.yml`.
