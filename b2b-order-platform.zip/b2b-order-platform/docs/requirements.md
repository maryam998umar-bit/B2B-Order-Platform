# Requirements (Week 1 artifact: refine with your own analysis)
- **Stakeholder:** distributor operations manager; secondary: B2B buyers.
- **Success metrics:** zero oversold orders under concurrent checkout; every state change audited; order-to-invoice in one request.
- **Scope:** no payments, no shipping carrier integration, single currency.
- **Acceptance:** see README "Handbook mapping"; add test evidence in `docs/evidence/`.
