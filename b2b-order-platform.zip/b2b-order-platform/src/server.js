const fs = require('fs');
const path = require('path');
const express = require('express');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const { DATABASE_URL, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD, PORT = 3000 } = process.env;
const pool = new Pool({ connectionString: DATABASE_URL });
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const wrap = fn => (req, res, next) => fn(req, res).catch(next);
const isInt = (v, min = 1) => Number.isInteger(v) && v >= min;
const stockStatus = p => p.stock <= 0 ? 'out_of_stock' : p.stock <= p.low_stock_threshold ? 'low_stock' : 'in_stock';
const audit = (db, actorId, action, entity, entityId, detail = null) =>
  db.query('INSERT INTO audit_logs(actor_id,action,entity,entity_id,detail) VALUES($1,$2,$3,$4,$5)',
    [actorId, action, entity, String(entityId ?? ''), detail]);

async function migrate() {
  await pool.query('CREATE TABLE IF NOT EXISTS schema_migrations(name TEXT PRIMARY KEY)');
  const dir = path.join(__dirname, '..', 'migrations');
  for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort()) {
    const done = await pool.query('SELECT 1 FROM schema_migrations WHERE name=$1', [f]);
    if (done.rowCount) continue;
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(fs.readFileSync(path.join(dir, f), 'utf8'));
      await client.query('INSERT INTO schema_migrations(name) VALUES($1)', [f]);
      await client.query('COMMIT');
      console.log('migrated', f);
    } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
  }
}

async function seed() {
  if (ADMIN_EMAIL && ADMIN_PASSWORD) {
    const hash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    await pool.query(`INSERT INTO users(email,password_hash,company,role) VALUES($1,$2,'Distributor HQ','admin') ON CONFLICT DO NOTHING`, [ADMIN_EMAIL.toLowerCase(), hash]);
  }
  const { rows } = await pool.query('SELECT count(*)::int AS n FROM products');
  if (rows[0].n === 0) {
    const demo = [['SKU-1001', 'Copy Paper A4 (box)', 2499, 120], ['SKU-1002', 'Ballpoint Pens (100)', 1299, 8],
      ['SKU-1003', 'Stapler Heavy Duty', 1899, 40], ['SKU-1004', 'Toner Cartridge', 8999, 0]];
    for (const d of demo) await pool.query('INSERT INTO products(sku,name,unit_price_cents,stock) VALUES($1,$2,$3,$4)', d);
  }
}

const auth = (roles) => (req, res, next) => {
  const h = req.headers.authorization || '';
  try {
    const user = jwt.verify(h.replace(/^Bearer /, ''), JWT_SECRET);
    if (roles && !roles.includes(user.role)) throw new HttpError(403, 'Forbidden');
    req.user = user; next();
  } catch (e) { next(e instanceof HttpError ? e : new HttpError(401, 'Unauthorized')); }
};
const sign = u => jwt.sign({ id: u.id, role: u.role, email: u.email }, JWT_SECRET, { expiresIn: '8h' });

app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.post('/api/auth/register', wrap(async (req, res) => {
  const { email, password, company = '' } = req.body || {};
  if (typeof email !== 'string' || !/^\S+@\S+\.\S+$/.test(email)) throw new HttpError(400, 'Valid email required');
  if (typeof password !== 'string' || password.length < 8) throw new HttpError(400, 'Password must be at least 8 characters');
  const hash = await bcrypt.hash(password, 10);
  try {
    const { rows } = await pool.query(
      `INSERT INTO users(email,password_hash,company,role) VALUES($1,$2,$3,'customer') RETURNING id,email,role`,
      [email.toLowerCase(), hash, String(company).slice(0, 120)]);
    await audit(pool, rows[0].id, 'register', 'user', rows[0].id);
    res.status(201).json({ token: sign(rows[0]), role: rows[0].role });
  } catch (e) {
    if (e.code === '23505') throw new HttpError(409, 'Email already registered');
    throw e;
  }
}));

app.post('/api/auth/login', wrap(async (req, res) => {
  const { email, password } = req.body || {};
  const { rows } = await pool.query('SELECT * FROM users WHERE email=$1', [String(email || '').toLowerCase()]);
  if (!rows[0] || !(await bcrypt.compare(String(password || ''), rows[0].password_hash))) throw new HttpError(401, 'Invalid credentials');
  await audit(pool, rows[0].id, 'login', 'user', rows[0].id);
  res.json({ token: sign(rows[0]), role: rows[0].role });
}));

app.get('/api/products', auth(), wrap(async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM products WHERE active ORDER BY id');
  res.json(rows.map(p => ({ ...p, stock_status: stockStatus(p) })));
}));

app.post('/api/products', auth(['admin']), wrap(async (req, res) => {
  const { sku, name, unit_price_cents, stock = 0 } = req.body || {};
  if (!sku || !name || !isInt(unit_price_cents, 0) || !isInt(stock, 0)) throw new HttpError(400, 'sku, name, unit_price_cents, stock required');
  try {
    const { rows } = await pool.query('INSERT INTO products(sku,name,unit_price_cents,stock) VALUES($1,$2,$3,$4) RETURNING *', [sku, name, unit_price_cents, stock]);
    await audit(pool, req.user.id, 'create', 'product', rows[0].id, rows[0]);
    res.status(201).json(rows[0]);
  } catch (e) { if (e.code === '23505') throw new HttpError(409, 'SKU exists'); throw e; }
}));

app.patch('/api/products/:id', auth(['admin']), wrap(async (req, res) => {
  const { stock, unit_price_cents } = req.body || {};
  if (stock !== undefined && !isInt(stock, 0)) throw new HttpError(400, 'Invalid stock');
  if (unit_price_cents !== undefined && !isInt(unit_price_cents, 0)) throw new HttpError(400, 'Invalid price');
  const { rows } = await pool.query(
    'UPDATE products SET stock=COALESCE($2,stock), unit_price_cents=COALESCE($3,unit_price_cents) WHERE id=$1 RETURNING *',
    [req.params.id, stock ?? null, unit_price_cents ?? null]);
  if (!rows[0]) throw new HttpError(404, 'Product not found');
  await audit(pool, req.user.id, 'update', 'product', rows[0].id, { stock, unit_price_cents });
  res.json(rows[0]);
}));

const loadCart = async (uid) => (await pool.query(
  `SELECT c.product_id, c.quantity, p.name, p.sku, p.unit_price_cents, p.stock
   FROM cart_items c JOIN products p ON p.id=c.product_id WHERE c.user_id=$1 ORDER BY p.id`, [uid])).rows;

app.get('/api/cart', auth(['customer']), wrap(async (req, res) => {
  const items = await loadCart(req.user.id);
  res.json({ items, total_cents: items.reduce((s, i) => s + i.quantity * i.unit_price_cents, 0) });
}));

app.put('/api/cart/items', auth(['customer']), wrap(async (req, res) => {
  const { product_id, quantity } = req.body || {};
  if (!isInt(product_id) || !isInt(quantity, 0)) throw new HttpError(400, 'product_id and non-negative integer quantity required');
  if (quantity === 0) {
    await pool.query('DELETE FROM cart_items WHERE user_id=$1 AND product_id=$2', [req.user.id, product_id]);
  } else {
    const p = await pool.query('SELECT stock FROM products WHERE id=$1 AND active', [product_id]);
    if (!p.rows[0]) throw new HttpError(404, 'Product not found');
    if (quantity > p.rows[0].stock) throw new HttpError(409, `Only ${p.rows[0].stock} in stock`);
    await pool.query(`INSERT INTO cart_items(user_id,product_id,quantity) VALUES($1,$2,$3)
      ON CONFLICT (user_id,product_id) DO UPDATE SET quantity=EXCLUDED.quantity`, [req.user.id, product_id, quantity]);
  }
  res.json({ items: await loadCart(req.user.id) });
}));

app.post('/api/orders', auth(['customer']), wrap(async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const cart = (await client.query(
      `SELECT c.product_id, c.quantity, p.unit_price_cents, p.stock, p.name
       FROM cart_items c JOIN products p ON p.id=c.product_id
       WHERE c.user_id=$1 ORDER BY p.id FOR UPDATE OF p`, [req.user.id])).rows;
    if (!cart.length) throw new HttpError(400, 'Cart is empty');
    for (const i of cart) if (i.quantity > i.stock) throw new HttpError(409, `Insufficient stock for ${i.name}`);
    const total = cart.reduce((s, i) => s + i.quantity * i.unit_price_cents, 0);
    const order = (await client.query('INSERT INTO orders(user_id,total_cents) VALUES($1,$2) RETURNING *', [req.user.id, total])).rows[0];
    for (const i of cart) {
      await client.query('INSERT INTO order_items VALUES($1,$2,$3,$4)', [order.id, i.product_id, i.quantity, i.unit_price_cents]);
      await client.query('UPDATE products SET stock=stock-$2 WHERE id=$1', [i.product_id, i.quantity]);
    }
    const inv = `INV-${new Date().getFullYear()}-${String(order.id).padStart(6, '0')}`;
    await client.query('INSERT INTO invoices(order_id,invoice_number,amount_cents) VALUES($1,$2,$3)', [order.id, inv, total]);
    await client.query('DELETE FROM cart_items WHERE user_id=$1', [req.user.id]);
    await audit(client, req.user.id, 'place', 'order', order.id, { total_cents: total, invoice: inv });
    await client.query('COMMIT');
    res.status(201).json({ ...order, invoice_number: inv });
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
}));

app.get('/api/orders', auth(), wrap(async (req, res) => {
  const admin = req.user.role === 'admin';
  const { rows } = await pool.query(
    `SELECT o.*, i.invoice_number, u.email FROM orders o
     JOIN invoices i ON i.order_id=o.id JOIN users u ON u.id=o.user_id
     WHERE ($1 OR o.user_id=$2) ORDER BY o.id DESC`, [admin, req.user.id]);
  res.json(rows);
}));

app.get('/api/orders/:id/invoice', auth(), wrap(async (req, res) => {
  const o = (await pool.query('SELECT * FROM orders WHERE id=$1', [req.params.id])).rows[0];
  if (!o || (req.user.role !== 'admin' && o.user_id !== req.user.id)) throw new HttpError(404, 'Order not found');
  const invoice = (await pool.query('SELECT * FROM invoices WHERE order_id=$1', [o.id])).rows[0];
  const items = (await pool.query(
    `SELECT p.sku,p.name,oi.quantity,oi.unit_price_cents FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE oi.order_id=$1`, [o.id])).rows;
  res.json({ invoice, order: o, items });
}));

const NEXT = { placed: ['shipped', 'cancelled'], shipped: ['delivered'], delivered: [], cancelled: [] };
app.patch('/api/orders/:id/status', auth(['admin']), wrap(async (req, res) => {
  const { status } = req.body || {};
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const o = (await client.query('SELECT * FROM orders WHERE id=$1 FOR UPDATE', [req.params.id])).rows[0];
    if (!o) throw new HttpError(404, 'Order not found');
    if (!NEXT[o.status].includes(status)) throw new HttpError(409, `Cannot move ${o.status} -> ${status}`);
    if (status === 'cancelled') {
      await client.query(`UPDATE products p SET stock = p.stock + oi.quantity FROM order_items oi WHERE oi.order_id=$1 AND oi.product_id=p.id`, [o.id]);
    }
    await client.query('UPDATE orders SET status=$2 WHERE id=$1', [o.id, status]);
    await audit(client, req.user.id, 'status', 'order', o.id, { from: o.status, to: status });
    await client.query('COMMIT');
    res.json({ id: o.id, status });
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
}));

app.get('/api/audit', auth(['admin']), wrap(async (_req, res) => {
  res.json((await pool.query('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 200')).rows);
}));

app.use((err, _req, res, _next) => {
  if (!(err instanceof HttpError)) console.error(err);
  res.status(err.status || 500).json({ error: err.status ? err.message : 'Internal server error' });
});

(async () => {
  if (!DATABASE_URL || !JWT_SECRET) { console.error('DATABASE_URL and JWT_SECRET are required'); process.exit(1); }
  await migrate(); await seed();
  app.listen(PORT, () => console.log(`API on :${PORT}`));
})().catch(e => { console.error(e); process.exit(1); });
