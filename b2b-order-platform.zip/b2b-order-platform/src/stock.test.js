const test = require('node:test');
const assert = require('node:assert');
const status = (stock, t = 10) => stock <= 0 ? 'out_of_stock' : stock <= t ? 'low_stock' : 'in_stock';
test('stock status thresholds', () => {
  assert.strictEqual(status(0), 'out_of_stock');
  assert.strictEqual(status(8), 'low_stock');
  assert.strictEqual(status(50), 'in_stock');
});
